# Coverage-Width Tradeoffs in Rule-Constrained Expert-Crowd Aggregation

This repository develops a reproducible research pipeline for studying hidden
public preferences in hybrid expert-crowd decision systems. The 2026 MCM
Problem C data are treated as an empirical testbed, not as evidence that
public ballots are observed or point-identified.

Designated publication repository:
https://github.com/denglizhen-113/coverage-width-tradeoffs-rule-constrained-aggregation

The implementation covers data auditing, analysis-panel construction,
rule-aware constraint construction, sharp linear-programming bounds for
percentage-aggregation weeks, feasible ordinal ranking identification for
ranking and judge-save regimes, typed dynamic proxies, leakage-controlled
prediction validation, scenario-based mechanism comparisons, manuscript
generation, and submission-readiness audits.

## Current data inventory

The initial scan found one data file and no separate problem statement,
documentation, source code, or prior output files:

- `2026_MCM_Problem_C_Data.csv` (project-root source file; retained unchanged)
- `data/raw/2026_MCM_Problem_C_Data.csv` (immutable working copy)

Both files have SHA-256 digest
`EA99CAEC6EA243BDB450A1971A95BA8A95701A93BE7FF29F0BA3C57D72DDFF52`.
The data contain 421 contestant-season records and 53 columns. Scores are in a
wide layout, with columns named by week and judge rather than one row per
contestant-week.

## Quick start

Requirements:

- Conda on Windows for byte-identical reconstruction of the historical 26X
  table and figure hashes
- Exact analysis and test dependencies listed in `requirements.txt`
- Exact DOCX/PDF production dependencies listed in `requirements-docs.txt`

Create the locked binary environment, isolate it from user-level packages, and
install both pip inventories for the complete pipeline and full test suite:

```powershell
$env:CONDA_PKGS_DIRS = Join-Path (Get-Location) '.conda-pkgs'
conda create --yes --prefix .conda-env --file conda-lock-win-64.txt
$env:PYTHONNOUSERSITE = '1'
$env:MPLCONFIGDIR = Join-Path (Get-Location) '.mplconfig'
$py = Resolve-Path '.conda-env\python.exe'
& $py -m pip install --no-cache-dir -r requirements.txt -r requirements-docs.txt
```

The exact versions alone are sufficient for numerical agreement within the
declared tolerance. The win-64 Conda lock additionally fixes the compiled
NumPy/Pandas/Matplotlib stack needed by the preregistered Stage 26X-2 byte-hash
gate and historical PNG dimensions.

Installing only `requirements.txt` is sufficient for the numerical stages and
Stage 26X experiments, but not for Stage 25 document production or DOCX/PDF
snapshot tests.

Run the audit and preprocessing stages from the project root:

```powershell
python scripts/01_data_audit.py
python scripts/02_preprocess.py
python scripts/03_build_constraints.py
python scripts/04_partial_identification.py
python scripts/05_ranking_identification.py
python scripts/06_build_identification_features.py
python scripts/07_expert_crowd_divergence.py
python scripts/08_dynamic_preference_model.py
python scripts/09_prediction_experiments.py
python scripts/10_counterfactual_mechanisms.py
python scripts/11_robust_aggregation_evaluation.py
python scripts/12_update_manuscript_results.py
python scripts/13_leakage_and_claim_audit.py
python scripts/14_manuscript_quality_check.py
python scripts/15_submission_audit.py
```

To select a different input explicitly:

```powershell
python scripts/01_data_audit.py --input path/to/data.csv
```

The audit writes:

- `outputs/tables/data_audit_summary.csv`
- `outputs/tables/special_cases.csv`
- `outputs/logs/data_audit.md`

Preprocessing writes:

- `data/processed/panel_long.csv`
- `data/processed/week_level.csv`
- `data/processed/contestant_level.csv`
- `outputs/logs/preprocess_report.md`

Run the focused rule tests with:

```powershell
python -m unittest discover -s tests -v
python -m pytest tests -q
```

Run stages 03-12 from existing processed inputs with:

```powershell
python run_all.py --skip-preprocess
```

To regenerate the manuscript audits and the strict pre-submission review from
existing processed data, run:

```powershell
python run_all.py --skip-preprocess --submission-audit
```

This command also runs the stage-13 leakage audit and stage-14 manuscript
quality check before the stage-15 submission audit. The stage-15 journal-fit
assessment is deliberately critical and may recommend against the currently
named target venue.

To generate the overnight pre-submission strengthening materials without
regenerating models or overwriting the baseline manuscript sections, run:

```powershell
python run_all.py --skip-preprocess --overnight-submission
```

This command runs stages 13-16 from existing results. Stage 16 produces
SEPS-oriented manuscript copies, a strict fit assessment, literature-gap and
methods audits, submission-material placeholders, a figure/table plan, and a
Go/No-Go report. It records that SEPS scope and author-guide pages require
manual browser verification when they cannot be accessed from the runtime.

To freeze the present evidence and generate the general decision-analysis
submission line without changing the baseline manuscript or SEPS copies, run:

```powershell
python run_all.py --skip-preprocess --general-submission
```

This runs stage 17 only. It writes a hash manifest, journal-type strategy
matrix, general-revised manuscript materials, a verified-candidate literature
map, and a clear recommendation to redirect away from SEPS unless a genuine
public/service application is added.

Both pipeline commands are idempotent. They replace only their documented
generated outputs and never write to the source data.

## Stage 32 MATCOM scientific corrections

The current Elsevier *Mathematics and Computers in Simulation* candidate is
generated by Stage 32. This stage corrects the identified-set coverage
predicate, computes sharp ordinal rank-support endpoints with binary linear
optimization, reports metric-specific Monte Carlo standard errors and paired
uncertainty, audits Bayesian failures by parameter region, and reports the
season-28 rule-provenance sensitivity. It reads historical outputs without
overwriting them and writes a new versioned directory:

```powershell
python scripts/32_matcom_scientific_corrections.py
# equivalent dispatcher entry point
python run_all.py --stage 32
```

The primary outputs are:

- `outputs/stage32-matcom-scientific-corrections/tables/`
- `outputs/stage32-matcom-scientific-corrections/reports/`
- `outputs/stage32-matcom-scientific-corrections/MATCOM_revised_candidate_package/`

The candidate remains blocked from submission until the corrected commit is
published under a versioned tag, archived under a persistent DOI, and checked
in the authenticated Elsevier portal. The local script performs no remote or
portal actions.

## Stage 18-26 entry points

Post-Stage-17 scripts are opt-in. `run_all.py` never reruns them through its
default path, especially because Stages 21-24 are historical frozen outputs.
Stage 25HA-25HF and Stage 26Y are dated DSS/EJOR submission-preparation
generators retained for provenance. Their generated prose can describe the
repository, target journal, or release gates as they stood at that historical
stage; it is not the current SIMPAT submission state and must not be reused
without a new factual audit. Stage 26AF-1 is the current non-frozen research
draft; it supersedes Stage 26AD with the figure rebuild, complexity boundary,
wording corrections, and Figure 5 conversion. Stage 26AB will be the next
journal-migration stage and must use the Stage 26AF-1 manuscript as its source.
Use an explicit stage only in a clean checkout or when intentionally creating a
new versioned output set:

```powershell
python run_all.py --stage 18
python run_all.py --stage 19
python run_all.py --stage 20
python run_all.py --stage 21
python run_all.py --stage 22
python run_all.py --stage 23
python run_all.py --stage 24
python run_all.py --stage 25-0
python run_all.py --stage 25A
python run_all.py --stage 25-overnight
python run_all.py --stage 25B
python run_all.py --stage 25C
python run_all.py --stage 25D
python run_all.py --stage 25E
python run_all.py --stage 25F
python run_all.py --stage 25H
python run_all.py --stage 25HA
python run_all.py --stage 25HB
python run_all.py --stage 25HC-closure
python run_all.py --stage 25HC-title
python run_all.py --stage 25HD-reconstruct
python run_all.py --stage 25HE-finalize
python run_all.py --stage 25HE-repair
python run_all.py --stage 25HF
python run_all.py --stage 26W-figure
python run_all.py --stage 26X-1
python run_all.py --stage 26X-2
python run_all.py --stage 26X-3
python run_all.py --stage 26Y
```

Stage 25G additionally requires the local document-rendering helper directory:

```powershell
python run_all.py --stage 25G --documents-skill-root path/to/documents-skill
```

The exported-PDF audit has required artifact-specific paths and remains a
direct command:

```powershell
python scripts/25hd_audit_exported_pdf.py --pdf path/to/export.pdf --report outputs/logs/pdf_audit.md --render-dir outputs/pdf_audit_pages
```

Stages 26L, 26S, and 26V are forensic, critical-review, and fact-check reports
created from the retained manuscript, audit logs, DOCX/PDF inspection, and
external metadata captures. Stage 26Z is time-sensitive journal research based
on the Stage 26X-3 manuscript and official publisher pages. These are
human/model analytical records, not deterministic data products, and are not
claimed to be script-rebuildable. Stage 26W's revised manuscript and editorial
logs are likewise human/model edits; only its data-driven Figure 6 has a
deterministic entry point. Their exact input mapping is recorded in
`outputs/stage26AA/STAGE_ENTRYPOINT_COVERAGE.md`.

Constraint construction and partial identification write:

- `outputs/tables/constraint_summary.csv`
- `outputs/models/constraints/*.npz`
- `data/processed/preference_bounds_regime_p.csv`
- `outputs/tables/uncertainty_by_week_regime_p.csv`
- `outputs/figures/*regime_p.png`
- `outputs/logs/constraint_report.md`
- `outputs/logs/partial_identification_report.md`
- `data/processed/feasible_rankings_regime_r.csv`
- `data/processed/feasible_rankings_regime_rplus.csv`
- `outputs/tables/ranking_identification_summary_*.csv`
- `outputs/tables/identification_comparison_by_regime.csv`
- `outputs/figures/*identifiability*.png`
- `outputs/logs/ranking_identification_report_*.md`
- `data/processed/identification_features_long.csv`
- `data/processed/dynamic_public_appeal.csv`
- `outputs/tables/expert_crowd_divergence.csv`
- `outputs/tables/prediction_results*.csv`
- `outputs/tables/counterfactual_results_by_*.csv`
- `outputs/tables/robust_aggregation_results.csv`
- `outputs/tables/pareto_frontier_points.csv`
- `outputs/logs/{identification_features,expert_crowd_divergence,dynamic_preference,prediction,counterfactual,robust_aggregation}_report.md`
- `manuscript/method_propositions.md`

## Directory structure

| Path | Purpose |
|---|---|
| `data/raw/` | Immutable copies of supplied source data |
| `data/processed/` | Reproducibly derived analysis data |
| `outputs/figures/` | Generated figures |
| `outputs/tables/` | Generated result and diagnostic tables |
| `outputs/models/` | Serialized model artifacts |
| `outputs/logs/` | Machine-generated audit and pipeline reports |
| `manuscript/` | English journal-manuscript materials |
| `scripts/` | Command-line pipeline entry points |
| `src/` | Reusable research code |
| `tests/` | Automated tests and validation fixtures |

## Data semantics

The audit deliberately keeps several states distinct:

- A numeric `0` in all judge columns generally appears after a contestant has
  left and is treated as a possible structural value, not as missing data.
- `N/A` in the raw CSV is retained in raw-token counts and is parsed separately
  as a missing value for numeric analysis. In a fourth-judge column it may mean
  that only three judges were present.
- Empty CSV fields are counted independently from `N/A` and other explicit
  missing-value tokens.
- Scores above 10 are reported and preserved. They are not clipped.
- Week, active-status, withdrawal-week, no-elimination, double-elimination,
  and finale indicators are audit-time inferences. Their definitions and
  limitations are recorded in `outputs/logs/data_audit.md`.

No audit output should be interpreted as a recovered audience vote. Future
preference estimates must be described as latent, inferred, or partially
identified quantities.
