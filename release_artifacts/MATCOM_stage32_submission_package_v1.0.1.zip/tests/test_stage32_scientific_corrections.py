from __future__ import annotations

import itertools
import hashlib
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from src.dss_common import covers_truth, point_satisfies_constraints
from src.ranking_identification import (
    RankingWeekSpec,
    consistency_masks,
    exact_rank_support,
    orders_to_fan_ranks,
)


ROOT = Path(__file__).resolve().parents[1]
STAGE32 = ROOT / "outputs/stage32-matcom-scientific-corrections"
PACKAGE = STAGE32 / "MATCOM_revised_candidate_package"


def _spec(
    *,
    regime: str = "R_plus",
    judge_ranks: tuple[float, ...] = (1.0, 2.0, 3.0, 4.0),
    eliminated: tuple[int, ...] = (3,),
    withdrawn: tuple[int, ...] = (),
    finale: bool = False,
    placements: tuple[float, ...] | None = None,
) -> RankingWeekSpec:
    n_active = len(judge_ranks)
    placement_values = (
        np.asarray(placements, dtype=float)
        if placements is not None
        else np.full(n_active, np.nan)
    )
    return RankingWeekSpec(
        season=99,
        week=1,
        regime=regime,
        contestant_ids=tuple(f"c{index}" for index in range(n_active)),
        contestant_names=tuple(f"Candidate {index}" for index in range(n_active)),
        judge_totals=np.arange(n_active, 0, -1, dtype=float),
        judge_ranks=np.asarray(judge_ranks, dtype=float),
        eliminated_indices=eliminated,
        withdrawn_indices=withdrawn,
        no_elimination_week=False,
        double_elimination_week=len(eliminated) > 1,
        finale_week=finale,
        finale_order_available=finale and placements is not None,
        placements=placement_values,
        tie_policy="average_rank",
    )


def _enumerated_endpoints(
    spec: RankingWeekSpec, mechanism: str
) -> tuple[np.ndarray, np.ndarray]:
    orders = np.asarray(list(itertools.permutations(range(spec.n_active))), dtype=int)
    fan_ranks = orders_to_fan_ranks(orders)
    direct, weak = consistency_masks(spec, fan_ranks)
    feasible = weak if mechanism == "R_plus" else direct
    retained = fan_ranks[feasible]
    assert len(retained) > 0
    return retained.min(axis=0).astype(float), retained.max(axis=0).astype(float)


def test_joint_polytope_membership_is_not_projection_box_membership() -> None:
    lower = np.asarray([0.0, 0.0])
    upper = np.asarray([1.0, 1.0])
    truth = np.asarray([0.8, 0.2])
    A_ub = np.asarray([[1.0, -1.0]])
    b_ub = np.asarray([0.0])
    A_eq = np.asarray([[1.0, 1.0]])
    b_eq = np.asarray([1.0])
    bounds = ((0.0, 1.0), (0.0, 1.0))

    assert covers_truth(lower, upper, truth)
    assert not point_satisfies_constraints(
        truth, A_ub, b_ub, A_eq, b_eq, bounds
    )


@pytest.mark.parametrize("mechanism", ["R", "R_plus"])
@pytest.mark.parametrize(
    "spec",
    [
        _spec(),
        _spec(judge_ranks=(1.5, 1.5, 3.0, 4.0)),
        _spec(eliminated=(2, 3)),
        _spec(eliminated=(3,), withdrawn=(1,)),
        _spec(
            eliminated=(),
            finale=True,
            placements=(1.0, 2.0, 3.0, 4.0),
        ),
    ],
)
def test_exact_milp_endpoints_match_complete_enumeration(
    spec: RankingWeekSpec, mechanism: str
) -> None:
    expected_minimum, expected_maximum = _enumerated_endpoints(spec, mechanism)
    observed = exact_rank_support(spec, mechanism=mechanism)

    assert observed.feasible
    np.testing.assert_array_equal(observed.minimum_ranks, expected_minimum)
    np.testing.assert_array_equal(observed.maximum_ranks, expected_maximum)
    np.testing.assert_array_equal(
        observed.rank_widths, expected_maximum - expected_minimum
    )
    assert observed.solver_calls == 2 * spec.n_active


def test_exact_support_reports_ineligible_elimination_as_infeasible() -> None:
    spec = _spec(eliminated=(3,), withdrawn=(3,))
    observed = exact_rank_support(spec)
    assert not observed.feasible
    assert np.isnan(observed.normalized_mean_width)


def test_stage32_corrected_metrics_and_endpoint_audit_are_consistent() -> None:
    effects = pd.read_csv(STAGE32 / "tables/paired_elimination_effect_mcse.csv")
    positive = effects.loc[effects["condition"].eq("positive_noise")].iloc[0]
    assert positive["paired_replications"] == 45_000
    assert positive["joint_coverage_change_mean"] == pytest.approx(0.1176)
    assert positive["legacy_projection_change_mean"] == pytest.approx(
        0.0502888888889
    )
    assert positive["joint_coverage_change_mean"] > positive[
        "legacy_projection_change_mean"
    ]
    assert positive["joint_coverage_change_mcse"] > 0
    assert positive["width_change_mcse"] > 0

    audit = pd.read_csv(STAGE32 / "tables/ordinal_sampling_endpoint_audit.csv")
    assert len(audit) == 87
    assert audit["exact_minus_legacy_normalized_width"].min() >= -1e-8
    assert audit["exact_minus_legacy_normalized_width"].max() > 0


def test_stage32_bayesian_denominators_and_failures_reconcile() -> None:
    frame = pd.read_csv(STAGE32 / "tables/bayesian_undefined_by_region.csv")
    assert len(frame) == 12
    assert frame["denominator"].sum() == 60_000
    assert frame["undefined_rows"].sum() == 94
    assert frame.loc[
        frame["outcome_noise_probability"].eq(0.0), "undefined_rows"
    ].sum() == 10
    np.testing.assert_allclose(
        frame["undefined_rate"], frame["undefined_rows"] / frame["denominator"]
    )


def test_stage32_manuscript_and_highlights_obey_revised_claim_boundaries() -> None:
    manuscript = (PACKAGE / "MATCOM_main_manuscript_source.md").read_text(
        encoding="utf-8"
    )
    assert "0.117600" in manuscript
    assert "joint-set coverage" in manuscript
    assert "95% equal-tail" in manuscript
    assert "possible and necessary winners" in manuscript
    assert "Diana Nyad" in manuscript
    assert "not **preregistered**" in manuscript
    assert "Computational complexity" not in manuscript
    assert "Figure 3b" not in manuscript
    assert "Figure 4b" not in manuscript
    assert "MSC (2020)" not in manuscript
    assert "Yuxin Liu: Resources; Data curation; Validation." in manuscript
    assert "Bo Li: Resources; Data curation; Writing - review and editing." in manuscript
    assert "The authors declare" in manuscript

    highlights = [
        line[2:]
        for line in (PACKAGE / "MATCOM_Highlights.txt")
        .read_text(encoding="utf-8")
        .splitlines()
        if line.startswith("- ")
    ]
    assert 3 <= len(highlights) <= 5
    assert all(len(line) <= 85 for line in highlights)
    assert len(highlights) == 5

    with zipfile.ZipFile(PACKAGE / "MATCOM_Highlights.docx") as archive:
        highlights_document = ET.fromstring(archive.read("word/document.xml"))
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    assert sum(1 for _ in highlights_document.iter(namespace + "p")) >= 6


def test_stage32_docx_uses_office_math_and_matches_three_author_metadata() -> None:
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    math_namespace = "{http://schemas.openxmlformats.org/officeDocument/2006/math}"
    with zipfile.ZipFile(PACKAGE / "MATCOM_main_manuscript.docx") as archive:
        document = ET.fromstring(archive.read("word/document.xml"))
    text = "".join(node.text or "" for node in document.iter(namespace + "t"))
    assert sum(1 for _ in document.iter(math_namespace + "oMath")) >= 10
    assert r"\sum" not in text and r"\forall" not in text
    math_text = "".join(node.text or "" for node in document.iter(math_namespace + "t"))
    assert all(token not in math_text for token in ("\\sum", "\\forall", "\\in", "\\le", "\\ge"))
    assert all(token in math_text for token in ("∑", "∀", "∈", "≤", "≥"))
    assert "C_box=1{l_i≤ p_i^★≤ u_i ∀ i}." in math_text

    title = (PACKAGE / "MATCOM_title_page_source.md").read_text(encoding="utf-8")
    cover = (PACKAGE / "MATCOM_cover_letter_source.md").read_text(encoding="utf-8")
    assert all(name in title for name in ("Lizhen Deng", "Yuxin Liu", "Bo Li"))
    assert "approved by all authors" in cover
    assert "The authors declare no competing interests" in cover


def test_stage32_reference_list_matches_in_text_citations() -> None:
    manuscript = (PACKAGE / "MATCOM_main_manuscript_source.md").read_text(
        encoding="utf-8"
    )
    body, references = manuscript.split("## References", 1)
    cited: set[int] = set()
    for match in re.finditer(r"\[(\d+(?:[-,]\d+)*)\]", body):
        for component in match.group(1).split(","):
            if "-" in component:
                start, end = (int(value) for value in component.split("-", 1))
                cited.update(range(start, end + 1))
            else:
                cited.add(int(component))
    listed = {int(match.group(1)) for match in re.finditer(r"(?m)^\[(\d+)\] ", references)}
    assert cited == listed


def test_stage32_manifest_matches_every_packaged_file() -> None:
    manifest = (PACKAGE / "PACKAGE_MANIFEST.md").read_text(encoding="utf-8")
    pattern = re.compile(r"^\| (.*?) \| (\d+) \| ([0-9A-F]{64}) \|$", re.MULTILINE)
    rows = pattern.findall(manifest)
    files = sorted(
        path
        for path in PACKAGE.rglob("*")
        if path.is_file() and path.name != "PACKAGE_MANIFEST.md"
    )
    assert len(rows) == len(files)
    observed = {relative: (int(size), digest) for relative, size, digest in rows}
    for path in files:
        relative = path.relative_to(PACKAGE).as_posix()
        digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
        assert observed[relative] == (path.stat().st_size, digest)
