# Stage 32 MATCOM Scientific-Correction Status

Status: `SCIENTIFIC_CORRECTIONS_COMPLETE_EXTERNAL_ARCHIVE_PENDING`.

The target journal is Elsevier's *Mathematics and Computers in Simulation* (MATCOM), not AMS *Mathematics of Computation*. The AMS-specific MSC, PDF-first, and AMS review-model requests in the supplied report are therefore excluded as venue-confused requirements. All scientifically applicable comments were addressed.

## Completed scientific corrections

- Joint feasible-set coverage replaces Cartesian marginal-box coverage. Positive-noise removal effect: 0.117600 (MCSE 0.001519); legacy projection effect: 0.050289.
- Exact MILP endpoints cover 87 empirical ordinal weeks and all four tie policies; the primary analysis uses 2,964 solver calls.
- Performance-specific MCSE, paired-effect uncertainty, region-level Bayesian failures, and season-28 provenance sensitivity are generated tables.
- “Preregistered” is replaced by “predeclared and hash-locked.”
- Unmeasured descriptor panels and governance matrices are removed from the main article.
- The revised candidate contains 18 manifested files before the manifest itself.

## Mandatory external author gates before submission

1. Publish the Stage 32 corrected code and evidence under a versioned repository tag.
2. Deposit that release in a persistent archive and insert its DOI and release SHA-256.
3. Confirm the Elsevier Editorial Manager article type, upload slots, and review model.
4. Reconfirm author metadata and inspect the portal-generated PDF.

No remote repository, archive, or submission portal was changed by this script.
